Op Kirka hacks
